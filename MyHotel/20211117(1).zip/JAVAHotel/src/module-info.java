module JAVAHotel {
}